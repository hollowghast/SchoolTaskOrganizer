var clock, clockInterval;

function doClock(){
	var clockButton;
	clock = document.getElementById("clockElement");
	clockButton = document.getElementById("clockButton");
	
	if (clockButton.value == "off"){
		clockButton.innerHTML = "Disable Clock";
		clockButton.value = "on";
		clock.innerHTML = "Enabled";
		
		clockInterval = window.setInterval(syncClock, 450);
	}
	else{
		clearInterval(clockInterval);
		clockButton.innerHTML = "Enable Clock";
		clock.innerHTML = "";
		clockButton.value = "off";
	}
	
}

function syncClock(){
	var time = new Date();
	//clock.innerHTML = new String().concat(time.getHours(), ":", time.getMinutes(), ":",
	//										time.getSeconds());
	clock.innerHTML = time.toLocaleTimeString();
}

function openLoginForm(){
	document.getElementById("loginButton").style.display = "none";
	document.getElementById("loginForm").style.display = "block";
}

function closeLoginForm(){
	document.getElementById("loginButton").style.display = "inline";
	document.getElementById("loginForm").style.display = "none";
}

