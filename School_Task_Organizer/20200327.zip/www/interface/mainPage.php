<?php
	session_start();
?>

<!DOCTYPE html>
<html>

<head>
	<title>All Tasks</title>
	
	<link rel="stylesheet" href="../style/common.css">
	
	<meta charset="UTF-8">
	<meta name="description" content="Seite zur Verwaltung meiner Tasks für die Schule (mit Erweiterungspotential)">
	<meta name="author" content="Daniel Deuerlein">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<base href="media" target="_blank">
	
	<script src="../scripts/mainScript.js"></script>
	<!-- <script>
		window.onload = function() {
			var element = document.createElement("script");
			element.src = "../scripts/mainScript.js";
			document.body.appendChild(element);
		};
	</script> -->
</head>

<body>
	<p>Test</p>
	<a href="register.php">Register</a>
	<br><hr>
	
	<button onclick="openLoginForm()" id="loginButton">Login</button>
	<form method="POST" action="login.php" id="loginForm">
		<label>Username:</label>
		<input type="textfield" cols="20" id="tfUsername" placeholder="Your Username" />
		<br>
		<label>Password:</label>
		<input type="password" cols="20" id="tfPassword" placeholder="Your Password" />
		<br>
		<!-- Delegates to login.php where data gets compared with DB -->
		<input type="submit" value="Send" />
		
		<input type="button" onclick="closeLoginForm()" value="Collapse" />
		<input type="reset" value="Reset" />
	</form>
	
	<button onclick="doClock()" id="clockButton" value="off">Enable Clock</button>
	<div id="clockElement"></div>
	
	<h3>Tasks</h3>
	<?php
		//get User (registered or logged in) -> Cookies
			//if guest -> show all
		//Open DB Connection
			//filter relevant tasks
		//Show tasks
	?>
	
	<?php
		phpinfo();
	?>
</body>

</html>